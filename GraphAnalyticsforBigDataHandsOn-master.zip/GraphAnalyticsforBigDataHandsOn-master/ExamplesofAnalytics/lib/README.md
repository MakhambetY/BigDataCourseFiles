Libraries Downloaded From
=========================

https://oss.sonatype.org/content/repositories/releases/org/graphstream/gs-core/1.2/gs-core-1.2.jar
https://oss.sonatype.org/content/repositories/releases/org/graphstream/gs-ui/1.2/gs-ui-1.2.jar
http://repo.spring.io/libs-release-remote/org/scalanlp/breeze_2.10/0.9/breeze_2.10-0.9.jar
http://repo1.maven.org/maven2/org/scalanlp/breeze-viz_2.10/0.9/breeze-viz_2.10-0.9.jar
https://repository.jboss.org/nexus/content/repositories/thirdparty-releases/jfree/jcommon/1.0.16/jcommon-1.0.16.jar
http://repo1.maven.org/maven2/jfree/jfreechart/1.0.13/jfreechart-1.0.13.jar
http://central.maven.org/maven2/org/graphstream/pherd/1.0/pherd-1.0.jar
